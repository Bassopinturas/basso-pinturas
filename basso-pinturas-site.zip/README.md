# 🎨 Basso Pinturas

Site institucional da empresa Basso Pinturas, especializada em reformas e pintura de fachadas em Erechim e região.

## 🔗 Acesse o site

➡️ https://bassopinturas.github.io/basso-pinturas

## 🚀 Como rodar localmente

```bash
git clone https://github.com/Bassopinturas/basso-pinturas.git
cd basso-pinturas
# Abra o arquivo index.html no navegador
```

## 🛠️ Tecnologias

- HTML5
- CSS3
- GitHub Pages (hospedagem gratuita)

## 📷 Contato

- WhatsApp: [Clique aqui](https://wa.me/555499205333)
- Instagram: [@basso.pinturas](https://instagram.com/basso.pinturas)
